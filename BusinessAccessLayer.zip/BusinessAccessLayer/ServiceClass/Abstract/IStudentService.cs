﻿using ModelAccessLayer;

namespace BusinessAccessLayer.ServiceClass.Abstract
{
    public interface IStudentService
    {
        IEnumerable<HighSchoolsStandardResult> GetAllStudents();
        HighSchoolsStandardResult GetStudentById(int Id);
        bool AddStudent(HighSchoolsStandardResult student);
        bool UpdateStudent(HighSchoolsStandardResult student);
        void DeleteStudent(int Id);
    }
}

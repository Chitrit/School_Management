﻿using ModelAccessLayer;

namespace BusinessAccessLayer.ClassService.Abstract
{
    public interface IContact
    {

        Task<bool> AddDetails(Contact model);
    }
}

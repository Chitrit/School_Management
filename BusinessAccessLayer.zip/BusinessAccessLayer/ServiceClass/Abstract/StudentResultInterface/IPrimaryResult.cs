﻿using ModelAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Abstract.StudentResultInterface
{
    public interface IPrimaryResult
    {
        IEnumerable<PrimaryResult_Model> GetAllStudents();
        PrimaryResult_Model GetStudentById(int Id);
        bool AddStudent(PrimaryResult_Model PrimaryResult);
        bool UpdateStudent(PrimaryResult_Model PrimaryResult);
        void DeleteStudent(int Id);
    }
}

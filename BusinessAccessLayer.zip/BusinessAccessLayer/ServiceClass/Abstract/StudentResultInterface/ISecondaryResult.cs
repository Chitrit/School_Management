﻿using ModelAccessLayer;
using ModelAccessLayer.Student_Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Abstract.StudentResultInterface
{
    public interface ISecondaryResult
    {
        IEnumerable<SecondaryResult_Model> GetAllStudents();
        SecondaryResult_Model GetStudentById(int Id);
        bool AddStudent(SecondaryResult_Model SecondaryResult);
        bool UpdateStudent(SecondaryResult_Model SecondaryResult);
        void DeleteStudent(int Id);
    }
}

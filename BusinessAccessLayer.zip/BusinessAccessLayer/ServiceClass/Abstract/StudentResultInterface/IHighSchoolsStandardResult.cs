﻿using ModelAccessLayer;
using ModelAccessLayer.Student_Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Abstract.StudentResultInterface
{
    public interface IHighSchoolsStandardResult
    {
        IEnumerable<HighSchoolsStandardResult_Model> GetAllStudents();
        HighSchoolsStandardResult_Model GetStudentById(int Id);
        bool AddStudent(HighSchoolsStandardResult_Model HighSchool);
        bool UpdateStudent(HighSchoolsStandardResult_Model HighSchool);
        void DeleteStudent(int Id);
    }
}

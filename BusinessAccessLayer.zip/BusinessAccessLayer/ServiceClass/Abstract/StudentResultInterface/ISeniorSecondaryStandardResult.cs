﻿using ModelAccessLayer;
using ModelAccessLayer.Student_Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Abstract.StudentResultInterface
{
    public interface ISeniorSecondaryStandardResult
    {
        IEnumerable<SeniorSecondaryStandardResult_Model> GetAllStudents();
        SeniorSecondaryStandardResult_Model GetStudentById(int Id);
        bool AddStudent(SeniorSecondaryStandardResult_Model SeniorSecondary);
        bool UpdateStudent(SeniorSecondaryStandardResult_Model SeniorSecondary);
        void DeleteStudent(int Id);
    }
}

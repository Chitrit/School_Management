﻿namespace BusinessAccessLayer.ServiceClass.Abstract
{
    public interface IAttendanceService
    {
       public bool MarkAttendance(int studentId, DateTime date);
    }
}

﻿using ModelAccessLayer.RoleViewModel;

namespace BusinessAccessLayer.ServiceClass.Abstract
{
    public interface IAdmin
    {
        Task<bool> CreateNewRole(CreateRoleViewModel adminRole);
        IEnumerable<CreateRoleViewModel> GetRoleList();
        Task<EditRoleViewModel> GetEditRoleListByID(string id);
        Task<bool> UpdateRole(EditRoleViewModel editRoleViewModel);
    }
}

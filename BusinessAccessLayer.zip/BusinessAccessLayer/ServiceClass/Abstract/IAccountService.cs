﻿using ModelAccessLayer;
using ModelAccessLayer.RoleViewModel;

namespace BusinessAccessLayer.ServiceClass.Abstract
{
    public interface IAccountService
    {
        Task <string> LoginAccount(LoginViewModel model);
        Task<bool> RegisterAccount(RegisterViewModel ViewModel);
        Task<bool> Logout();

        
    }
}

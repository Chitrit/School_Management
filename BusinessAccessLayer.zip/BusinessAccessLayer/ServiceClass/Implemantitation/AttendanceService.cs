﻿using BusinessAccessLayer.ServiceClass.Abstract;
using DataAccessLayer.Data;
using ModelAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Implemantitation
{
    public class AttendanceService : IAttendanceService
    {
        private readonly SchoolManagementDbContext _context;

        public AttendanceService(SchoolManagementDbContext context)
        {
            _context = context;
        }

        public bool MarkAttendance(int studentId, DateTime date)
        {
            // Check if attendance for the student on the given date already exists
            var existingAttendance = _context.Attendances
                .FirstOrDefault(a => a.StudentId == studentId && a.Date.Date == date.Date);

            if (existingAttendance == null)
            {
                // Create a new attendance record
                var newAttendance = new AttendanceModel
                {
                    StudentId = studentId,
                    Date = date,
                    IsPresent = true
                };

                _context.Attendances.Add(newAttendance);
            }
            else
            {
                // Update existing attendance record
                existingAttendance.IsPresent = true;
            }
            _context.SaveChanges();
            return true;
        }

        // Other methods for attendance-related operations

    }

}



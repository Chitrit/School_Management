﻿using BusinessAccessLayer.ServiceClass.Abstract;
using DataAccessLayer;
using DataAccessLayer.Data;
using Microsoft.AspNetCore.Identity;
using ModelAccessLayer.RoleViewModel;

namespace BusinessAccessLayer.ServiceClass.Implemantitation
{
    public class AdminService : IAdmin
    {
        private readonly SchoolManagementDbContext _school;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;
        public AdminService(SchoolManagementDbContext school, RoleManager<IdentityRole> roleManager,UserManager<ApplicationUser> userManager)
        {
            _school = school;
            _roleManager = roleManager;
            _userManager = userManager;
        }

        public async Task<bool> CreateNewRole(CreateRoleViewModel createRoleViewModel)
        {
            IdentityRole identityRole = new IdentityRole
            {
                Name = createRoleViewModel.RoleName
            };
            IdentityResult result = await _roleManager.CreateAsync(identityRole);
            if (result.Succeeded)
            {
                return true;
            }
            return false;
        }

        public async Task<EditRoleViewModel> GetEditRoleListByID(string id)
        {
           var role = await _roleManager.FindByIdAsync(id);

            var model = new EditRoleViewModel
            {
                Id = role.Id,
                RoleName = role.Name
            };

            foreach (var user in _userManager.Users)
            {
                if(await _userManager.IsInRoleAsync(user, role.Name))
                {
                    model.Users.Add(user.UserName);
                }
            }
            return model;
        }

        public IEnumerable<CreateRoleViewModel> GetRoleList()
        {
            List<CreateRoleViewModel> roleList = new List<CreateRoleViewModel>();
            var roles = _roleManager.Roles.ToList();
            if (roles != null)
            {
                foreach (var item in roles)
                {
                    CreateRoleViewModel role = new CreateRoleViewModel()
                    {
                        RoleName = item.Name,
                    };
                    roleList.Add(role);

                }
            }
            return roleList;
        }

        public async Task<bool> UpdateRole(EditRoleViewModel editRoleViewModel)
        {
            IdentityRole identityRole = new IdentityRole { Name = editRoleViewModel.RoleName };
            var  result = await _roleManager.UpdateAsync(identityRole);

            if (!result.Succeeded)
            {
                return true;
            }
           return false;
        }
    }
}

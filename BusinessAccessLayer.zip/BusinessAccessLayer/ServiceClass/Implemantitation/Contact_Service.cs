﻿using BusinessAccessLayer.ClassService.Abstract;
using DataAccessLayer.Data;
using ModelAccessLayer;

namespace BusinessAccessLayer.ClassService.Implemantitation
{
    public class Contact_Service : IContact
    {
        private readonly SchoolManagementDbContext _context;

        public Contact_Service(SchoolManagementDbContext context1)
        {
            _context = context1;
        }

        public async Task<bool> AddDetails(Contact model)
        {
            try
            {
                var check = _context.Contact.Where(x => x.Id == model.Id).FirstOrDefault();
                if (check != null)
                {
                    Contact contact = new Contact();
                    contact.Name = model.Name;
                    contact.Email = model.Email;
                    contact.Subject = model.Subject;
                    contact.Message = model.Message;

                }
                _context.Contact.Add(model);
                int result = await _context.SaveChangesAsync();
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                throw;
            }
         
        }
    }
}

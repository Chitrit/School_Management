﻿using BusinessAccessLayer.ServiceClass.Abstract.StudentResultInterface;
using DataAccessLayer.Data;
using Microsoft.EntityFrameworkCore;
using ModelAccessLayer;
using ModelAccessLayer.Student_Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Implemantitation.StudentResultService
{
    public class HighSchoolsStandardResultService : IHighSchoolsStandardResult
    {
        private readonly SchoolManagementDbContext _school;
        public HighSchoolsStandardResultService(SchoolManagementDbContext school)
        {
            _school = school;
        }

        public bool AddStudent(HighSchoolsStandardResult_Model HighSchool)
        {
            _school.HighSchoolsStandardResult_tbl.Add(HighSchool);
            var check = _school.SaveChanges();
            if (check > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void DeleteStudent(int Id)
        {
            var result = _school.HighSchoolsStandardResult_tbl.Where(x => x.Id == Id);
            if(result != null)
            {
                _school.Remove(result);
            } 
        }

        public HighSchoolsStandardResult_Model GetStudentById(int Id)
        {
            return _school.HighSchoolsStandardResult_tbl.Where(x => x.Id == Id).FirstOrDefault();
        }

        public bool UpdateStudent(HighSchoolsStandardResult_Model HighSchool)
        {
            _school.HighSchoolsStandardResult_tbl.Update(HighSchool);
            var check = _school.SaveChanges();
            if(check > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        IEnumerable<HighSchoolsStandardResult_Model> IHighSchoolsStandardResult.GetAllStudents()
        {
            return _school.HighSchoolsStandardResult_tbl.ToList();
        }
    }
}

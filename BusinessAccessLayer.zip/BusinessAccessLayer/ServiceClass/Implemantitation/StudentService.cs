﻿using BusinessAccessLayer.ServiceClass.Abstract;
using DataAccessLayer.Data;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using ModelAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessAccessLayer.ServiceClass.Implemantitation
{
    public class StudentService : IStudentService
    {
        private readonly SchoolManagementDbContext _context;

        public StudentService(SchoolManagementDbContext context)
        {
            _context = context;
        }
      
        public bool AddStudent(HighSchoolsStandardResult student)
        {
           _context.Students.Add(student);
            var check = _context.SaveChanges();
            if (check > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void DeleteStudent(int Id)
        {
            var result = _context.Students.Where(x => x.Id == Id);
            if (result != null)
            {
                _context.Remove(result);
            }
        }

        public IEnumerable<HighSchoolsStandardResult> GetAllStudents()
        {
            return _context.Students.ToList();
        }

        public HighSchoolsStandardResult GetStudentById(int Id)
        {
            return _context.Students.Where(x => x.Id== Id).FirstOrDefault();
        }

        public bool UpdateStudent(HighSchoolsStandardResult student)
        {
            _context.Students.Update(student);
            var check = _context.SaveChanges();
            if (check > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

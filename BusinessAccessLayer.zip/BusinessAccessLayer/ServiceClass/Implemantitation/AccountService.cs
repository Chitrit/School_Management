﻿using BusinessAccessLayer.ServiceClass.Abstract;
using DataAccessLayer;
using DataAccessLayer.Data;
using Microsoft.AspNetCore.Identity;
using ModelAccessLayer;
using ModelAccessLayer.RoleViewModel;

namespace BusinessAccessLayer.ServiceClass.Implemantitation
{
    public class AccountService : IAccountService
    {
       
        private readonly UserManager<ApplicationUser> _userManager;
         private readonly SignInManager<ApplicationUser> _signInManager;
        public AccountService(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        
        
       
       
        public async Task<string?> LoginAccount(LoginViewModel model)
        {
            try
            {            
                var result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, false);
                if (result.Succeeded)
                {
                    var user = await _userManager.FindByEmailAsync(model.Email);
                    if(user != null) 
                    {
                        var role = await _userManager.GetRolesAsync(user);
                        string role1 = role[0];
                        return role1;
                    }
                }
                return null;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<bool> Logout()
        {
            await _signInManager.SignOutAsync();
            return true;
        }

        public async Task<bool> RegisterAccount(RegisterViewModel registerViewModel)
        {
            var data = await _userManager.FindByEmailAsync(registerViewModel.Email);
            if (data == null)
            {
                var resu = new ApplicationUser()
                {
                    UserName = registerViewModel.UserName,
                    Email = registerViewModel.Email,
                };
                var result = await _userManager.CreateAsync(resu,registerViewModel.Password);
                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(resu, "Student");
                    return true;
                }
            }
            return false;
        }
    }
}

﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ModelAccessLayer;
using ModelAccessLayer.Student_Result;

namespace DataAccessLayer.Data
{
    public class SchoolManagementDbContext : IdentityDbContext<ApplicationUser>
    {
        public SchoolManagementDbContext(DbContextOptions<SchoolManagementDbContext> options) : base(options)
        {
        }
        public DbSet<HighSchoolsStandardResult_Model> Hightbl { get; set; }
        public DbSet<PrimaryResult_Model> PrimaryResult_tbl { get; set; }
        public DbSet<SecondaryResult_Model> SecondaryResult_tbl { get; set; }
        public DbSet<SeniorSecondaryStandardResult_Model> SeniorSecondary_tbl { get; set; }

        public DbSet<Contact> Contact { get; set; }
        public DbSet<ModelAccessLayer.HighSchoolsStandardResult> Students { get; set; }
        public DbSet<AttendanceModel> Attendances { get; set; }

        public IEnumerable<object> GetAllStudents()
        {
            throw new NotImplementedException();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
       
    }
}

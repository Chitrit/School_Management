﻿using DataAccessLayer.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using ModelAccessLayer;
using ModelAccessLayer.RoleViewModel;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace WebAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly SchoolManagementDbContext _dbContext;
        private readonly IConfiguration configutation;

        public ValuesController(SchoolManagementDbContext dbContext, IConfiguration configuration)
        {
            _dbContext = dbContext;
            configutation = configuration;
        }



        [AllowAnonymous]
        [HttpPost]
        [Route("api/Login")]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            _dbContext.Add(model);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("api/Registration")]
        public async Task<IActionResult> Registration(RegisterViewModel ViewModel)
        {
            if (ModelState.IsValid)
            {
                var result = _dbContext.Add(ViewModel);
                await _dbContext.SaveChangesAsync();
                if (result != null)
                {
                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    NotFound();
                }
            }
            return Ok();
        }


        [AllowAnonymous]
        [HttpPost]
        public IActionResult LoginAccount([FromBody] LoginViewModel model)
        {
           IActionResult response = Unauthorized();
           if (model != null)
            {
                if(model.Email.Equals("test@gmail.com") && model.Password.Equals("a"))
                {
                    var issuer = configutation["Jwt:Issuer"];
                    var audience = configutation["Jwt:Audience"];
                    var key = Encoding.UTF8.GetBytes(configutation["Jwt:Key"]);
                    var signingCredentials = new SigningCredentials(
                        new SymmetricSecurityKey(key),
                        SecurityAlgorithms.HmacSha512Signature
                        );
                    var subject = new ClaimsIdentity(new[]
                    {
                        new Claim(JwtRegisteredClaimNames.Sub, model.Email),
                        new Claim(JwtRegisteredClaimNames.Email, model.Email),
                    });

                    var expires = DateTime.UtcNow.AddMinutes(10);

                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = subject,
                        Expires = expires,
                        Issuer = issuer,
                        Audience = audience,
                        SigningCredentials = signingCredentials
                    };

                    var tokenHandler = new JwtSecurityTokenHandler();
                    var token = tokenHandler.CreateToken(tokenDescriptor);
                    var jwtToken = tokenHandler.WriteToken(token);

                    return Ok(jwtToken);
                }
            }
            return response;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelAccessLayer.Student_Result
{
    public class HighSchoolsStandardResult_Model
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string FatherName { get; set; }
        public string Address { get; set; }
        public string Gender { get; set; }
        public long RollNumber { get; set; }
        public DateOnly DOB { get; set; }
        public string Hindi { get; set; }
        public string English { get; set; }
        public string Math { get; set; }
        public string Science { get; set; }
        public string SocialScience { get; set; }
        public string Drawing { get; set; }
        public string Character { get; set; }
        public string Performance { get; set; }
        public string MarksObtained_MaximumMarks { get; set; }
        public string Result_Division { get; set; }
    }
}
